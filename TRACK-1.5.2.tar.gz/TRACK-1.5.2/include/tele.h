/* structure for Teleconnection statistics for a particular 
   Teleconnection value.                                     */

typedef struct tele {
   double tst;
   double h;
   int ktyp;
}TELE;
