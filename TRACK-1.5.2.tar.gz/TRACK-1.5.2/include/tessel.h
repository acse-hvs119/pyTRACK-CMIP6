
/* structure for use with the spherical tesselation routine */


struct cpt {
      float xct;
      float yct;
};
