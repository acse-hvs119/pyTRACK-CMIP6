
struct cvecs {
    double p1[4];
    double p2[4];
    double p3[4];
    double beta;
};


#define  EIGTOL   1.0E-6
