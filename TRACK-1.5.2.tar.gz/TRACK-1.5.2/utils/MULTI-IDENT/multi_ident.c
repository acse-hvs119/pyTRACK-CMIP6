#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "splice.h"
#include "mem_er.h" 

/* program to do identification for multiple fields */

struct tot_tr *read_tracks(FILE *, int *, int *, int *, int , float *, float * , float ** , int * );
void meantrd(FILE * , struct tot_tr * , int , int , int , int , float , float );

extern int nfld, nff;
extern int *nfwpos;

int noheader=0;

int main(void)
{
    int i=0, j=0, k=0;
    int trnum=0;
    int nft=0;
    int nct=0, nmct=0;
    int nmat=0;
    int nth=0;
    int gpr=0, ipr=0;

    int *ifld=NULL;
    int *ifncnt=NULL;
    int *imnmx=NULL;

    float alat=0.0, alng=0.0;

    float *fthr=NULL;

    float fadd=0.0;

    FILE *fin=NULL, *fout=NULL;

    char filin[MAXCHR];
    char filout[MAXCHR];

    struct tot_tr *tracks=NULL, *atr=NULL;
    struct fet_pt_tr *pt=NULL;

    printf("What track file is required?\n\n");
    scanf("%s", filin);

    strcpy(filout, filin);
    strcat(filout, ".mident");

    fin = fopen(filin, "r");
    if(!fin){
       printf("***ERROR***, unable to open file %s for 'r'\n\n", filin);
       exit(1);
    }

    tracks = read_tracks(fin, &trnum, &gpr, &ipr, 's', &alat, &alng, NULL, NULL);

    fclose(fin);

    printf("What is the number of contiguous points to satisfy the threshols?\n\n");
    scanf("%d", &nth);

    printf("How many fields are required to be tested?\n\n");
    scanf("%d", &nft);

    ifld = (int *)calloc(nft, sizeof(int));
    mem_er((ifld == NULL) ? 0 : 1, nft * sizeof(int));

    ifncnt = (int *)calloc(nft, sizeof(int));
    mem_er((ifncnt == NULL) ? 0 : 1, nft*sizeof(int));

    imnmx = (int *) calloc(nft, sizeof(int));
    mem_er((imnmx == NULL) ? 0 : 1, nft*sizeof(int));

    fthr = (float *) calloc(nft, sizeof(float));
    mem_er((fthr == NULL) ? 0 : 1, nft*sizeof(float));

    for(i=0; i < nft; i++){
       printf("What is the %d field required? Default field is '0'\n", i+1);
       scanf("%d", ifld + i);
       printf("\n"); 

       if(*(ifld + i) > nff){
          printf("****ERROR****, chosen added field Id to large.\n\n");
          exit(1);
       } 

       printf("Is a min or max test required, '0' for min or '1' for max.\n\n");
       scanf("%d", imnmx + i);
       if(*(imnmx + i) < 0 || *(imnmx + i) > 1){
          printf("****ERROR****, incorrect option chosen.\n\n");
          exit(1);
       }

       printf("What threshold is required for this field?\n");
       scanf("%f", fthr + i);

       if(*(ifld + i)){
          *(ifncnt + i) = 0;
          for(j=0; j < *(ifld + i); j++){
             if(*(nfwpos + j)) *(ifncnt + i) += 3;
             else *(ifncnt + i) += 1;
          }
          --(*(ifncnt + i));
       }

    }

    for(i=0; i < trnum; i++){
       atr = tracks + i;

       nct = 0;
       nmct = 0;

       for(j=0; j< atr->num; j++){
          pt = atr->trpt + j;
	  
	  nmat = 0;
          for(k=0; k < nft; k++){
              if(! *(ifld + k)){
                 if(! *(imnmx + k)){
                    if(pt->zf <= *(fthr + k)) ++nmat;
                 } 
                 else {
                    if(pt->zf >= *(fthr + k)) ++nmat;
                 }
              }
              else {
                 fadd = pt->add_fld[*(ifncnt + k)]; 

                 if(fadd > ADD_CHECK) continue;
                 if(! *(imnmx + k)){
                    if(fadd <= *(fthr + k)) ++nmat;
                 }
                 else {
 
                    if(fadd >= *(fthr + k)) {		    
		       ++nmat;
		    }
                 }

              }      
          } 

          if(nmat == nft) ++ nct;
          else nct = 0;
          
	  if(nct > nmct) nmct = nct;

       }

       if(nmct < nth){ 
         for(j=0; j < atr->num; j++){
            free((atr->trpt + j)->add_fld);
         }
         free(atr->trpt);
         atr->num = 0;
       }

    }

    fout = fopen(filout, "w");
    if(!fout){
       printf("***ERROR***, unable to open file %s for 'w'\n\n", filout);
       exit(1);
    }

    meantrd(fout, tracks, trnum, 's', gpr, ipr, alat, alng);

    fclose(fout);    

    free(ifld);
    free(imnmx);
    free(fthr);
    
    
    for(i=0; i < trnum; i++){   
        atr = tracks + i;
        for(j=0; j < atr->num; j++){
            free((atr->trpt + j)->add_fld);
        }
        free(atr->trpt);
        atr->num = 0;
    }
    free(tracks);

    return 0;
}
