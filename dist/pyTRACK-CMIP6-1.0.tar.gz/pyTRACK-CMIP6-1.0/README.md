# pyTRACK-CMIP6: A Python Wrapper Library to Adapt TRACK for CMIP6 Input and Extratropical Cyclone Analysis

Read me

Requirements (gcc, gfortran, standard netCDF setup, etc.)
